# 🛡️ Phishing Response Agent

**AI-powered Microsoft 365 account compromise investigation and automated remediation.**

Built for the Microsoft AI Hackathon 2026 — Track: **Reasoning Agents** using **Foundry IQ** (Azure AI Foundry).

> Responding to a phishing compromise in Microsoft 365 currently takes a skilled analyst 45–90 minutes across 5+ portals. This tool reduces it to under 5 minutes with a single interface and one-click remediation.

I built this because I kept doing the same incident-response checklist by hand every time an account got compromised — jumping between Entra, Exchange, Defender and the Azure portal. This agent runs that whole checklist for me and remediates in one click.

---

## What It Does

**1. Analyze** — Enter any user's email. The agent pulls live data from your Microsoft 365 tenant:
- Directory roles and privilege level (all admin types detected)
- MFA methods with phone numbers and device names
- Sign-in history — location, IP address, MFA used, success/fail
- Registered devices with registration dates and compliance status
- Inbox rules with AI verdict on whether each is suspicious
- Email forwarding status
- OAuth app grants — resolved to real app names, classified as Dangerous / High-Risk / Normal
- PIM/JIT role assignments
- Delegated mailbox access
- Sent emails for phishing spread detection

**2. AI Analysis** — Azure AI Foundry (GPT-4o-mini) summarizes all findings and recommends next steps tailored to the user's privilege level.

**3. AI Chat Agent** — Ask anything in plain English:
- "Any suspicious login locations?"
- "Show me the full response protocol"
- "Are there dangerous OAuth app grants?"
- "What devices were registered in the last 2 weeks?"

**4. Automated Remediation** — One click executes 8 steps via Microsoft Graph API:
1. Block account
2. Reset password (16-char cryptographically random, forceChangeNextSignIn)
3. Delete ALL MFA methods (verified)
4. Force MFA re-registration
5. Delete suspicious inbox rules
6. Clear email forwarding
7. Revoke all sessions + force Office sign-out
8. Re-enable account

For privileged accounts, also automatically checks: backdoor user accounts created, CA policy changes, PIM assignments, delegated access, Defender restricted sender status.

---

## Microsoft IQ Integration

This project uses **Foundry IQ** — Azure AI Foundry provides the reasoning layer that:
- Analyzes all tenant data and surfaces compromise indicators
- Adapts its response protocol based on the user's privilege level
- Answers free-form security questions grounded in live tenant data (not hallucinated)
- Classifies OAuth app grants as dangerous/safe based on scope analysis

---

## Setup

### Prerequisites
- A Microsoft 365 tenant
- An Azure App Registration with admin consent (see permissions below)
- Azure AI Foundry resource with a GPT-4o-mini deployment (or a GitHub token as fallback)

### 1. Create Azure App Registration

1. **Azure Portal** → **Microsoft Entra ID** → **App registrations** → **New registration**
2. Name it (e.g. "Phishing Response Agent") → Register
3. Note: **Application (client) ID** and **Directory (tenant) ID**
4. **Certificates & secrets** → New client secret → note the value
5. **API permissions** → Add → Microsoft Graph → Application permissions:

| Permission | Required For |
|---|---|
| `User.ReadWrite.All` | Read profile, disable/enable, reset password |
| `UserAuthenticationMethod.ReadWrite.All` | Read and delete MFA methods |
| `AuditLog.Read.All` | Sign-in logs, audit logs |
| `Directory.Read.All` | Roles, group memberships |
| `Mail.ReadWrite` | Read/delete inbox rules, clear forwarding |
| `MailboxSettings.ReadWrite` | Email forwarding settings |
| `Device.Read.All` | Registered devices |
| `Calendars.Read` | Delegated calendar access |
| `SecurityAlert.Read.All` | Defender alerts *(optional)* |
| `Policy.Read.All` | Conditional Access policies *(optional)* |
| `RoleManagement.Read.Directory` | PIM assignments *(optional)* |
| `TeamMember.Read.All` | Teams forensics *(optional)* |
| `Files.Read.All` | OneDrive forensics *(optional)* |

6. **Grant admin consent** ← important

### 2. Set Up Azure AI Foundry (for Foundry IQ)

1. **Azure Portal** → search "Azure AI Foundry" → Create a hub + project
2. **Deployments** → Deploy `gpt-4o-mini`
3. Note the **endpoint URL** and **API key**

### 3. Configure Environment

Copy `.env.template` to `.env` and fill in your values:

```env
MICROSOFT_TENANT_ID=your-tenant-id
MICROSOFT_CLIENT_ID=your-client-id
MICROSOFT_CLIENT_SECRET=your-client-secret

# Azure AI Foundry (preferred)
AZURE_AI_ENDPOINT=https://your-resource.openai.azure.com/openai/deployments/gpt-4o-mini
AZURE_AI_KEY=your-azure-ai-key

# GitHub Models (fallback if Foundry not configured)
GITHUB_TOKEN=ghp_your_token
```

### 4. Run

**Locally:**
```bash
pip install -r requirements.txt
python main.py
# Open http://localhost:8000
```

**On Replit:**
1. Upload this project or connect your GitHub repo
2. Add the environment variables in Replit **Secrets** (padlock icon) — same keys as `.env`
3. In Shell: `pip install -r requirements.txt` then `python main.py`
4. Click the preview URL that appears

---

## Architecture

```
main.py              — Startup, env validation
config.py            — Environment config (python-dotenv)
web/
  app.py             — FastAPI backend: /api/analyze, /api/ask-ai, /api/remediate
  index.html         — Single-page UI (chat panel left, results panel right)
graph_client.py      — All Microsoft Graph API calls
analyzer.py          — Privilege detection, sign-in log analysis
forensics.py         — 8-vector forensic analysis
executor.py          — 8-step remediation orchestrator
llm.py               — AI via Azure AI Foundry or GitHub Models
user_analyzer.py     — User activity and victim detection
requirements.txt     — Python dependencies
.env.template        — Environment variable template
```

---

## Notes

- Works on **any Microsoft 365 tenant** — no E5 required for core features
- One active analysis at a time; results cached in memory per user
- MFA methods may appear in Entra for ~60s after deletion (Graph eventual consistency)
- Missing optional permissions are handled gracefully — they log a warning and continue
- The app never stores credentials or user data to disk

## Known limitations / TODO

- Impossible-travel detection flags any country change, so legitimate travel can show as a false positive. Needs proper time-vs-distance math.
- Defender "Restricted entities" removal has no public Graph API, so it stays a manual step.
- After remediation the account is re-enabled, but the user must sign in with the *new* generated password — entering their old one will fail (this is how Entra's forced-change flow works).
- Sign-in logs need an Entra ID P1/P2 license on the tenant; on free tenants the sign-in section will be empty.
