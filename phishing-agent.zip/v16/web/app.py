from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import os
import logging
from config import config
from graph_client import GraphClient
from analyzer import Analyzer
from executor import Executor
from user_analyzer import UserAnalyzer
from forensics import ForensicAnalyzer
from llm import AIAnalyzer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("app")

app = FastAPI()
current_analysis = {}

class IncidentRequest(BaseModel):
    user_email: str
    question: Optional[str] = None  # Optional context/question

class AIQuestion(BaseModel):
    user_email: str
    question: str
    conversation_history: Optional[list] = None  # Multi-turn chat support

class RemediationApproval(BaseModel):
    approve: bool = True
    user_email: Optional[str] = None  # which analyzed user to remediate

@app.get("/")
async def root():
    return FileResponse(os.path.join(os.path.dirname(__file__), "index.html"))

@app.post("/api/analyze")
async def analyze(incident: IncidentRequest):
    """Analyze user account for compromise indicators"""
    try:
        analysis_key = incident.user_email.replace("@", "_").replace(".", "_")
        
        # Use cache for same user
        if analysis_key in current_analysis:
            logger.info(f"✓ Using cached analysis for {incident.user_email}")
            cached = current_analysis[analysis_key]
            return {
                "status": "analysis_complete",
                "cached": True,
                "user": cached.get("user", {}),
                "threat_score": cached.get("threat_score"),
                "threat_indicators": cached.get("threat_indicators"),
                "ai_summary": cached.get("ai_summary"),
                "findings": cached.get("findings"),
                "user_activity": cached.get("user_activity"),
                "affected_users": cached.get("affected_users"),
                "victims": cached.get("victims"),
                "mailbox_rules": cached.get("mailbox_rules"),
                "devices": cached.get("devices"),
                "device_details": cached.get("device_details"),
                "mfa_methods": cached.get("mfa_methods"),
                "mfa_details": cached.get("mfa_details"),
                "user_licenses": cached.get("user_licenses", []),
                "signin_analysis": cached.get("signin_analysis"),
                "signin_logs_raw": cached.get("signin_logs_raw", []),
                "pim_data": cached.get("pim_data", {}),
                "delegated_access": cached.get("delegated_access", []),
                "oauth_apps_raw": cached.get("oauth_apps_raw", []),
                "admin_data": cached.get("admin_data"),
                "phishing_victims": cached.get("phishing_victims"),
                "suspicious_rules": cached.get("suspicious_rules"),
                "forensic_analysis": cached.get("forensic_analysis"),
                "requires_approval": cached.get("requires_approval")
            }
        
        logger.info(f"\n{'='*70}\nANALYSIS: {incident.user_email}\n{'='*70}\n")
        
        graph = GraphClient(config.TENANT_ID, config.CLIENT_ID, config.CLIENT_SECRET)
        ai = AIAnalyzer(os.getenv("GITHUB_TOKEN", ""))
        user_analyzer = UserAnalyzer()
        analyzer = Analyzer()
        
        user = await graph.get_user(incident.user_email)
        if not user or "id" not in user:
            return {"error": f"User not found: {incident.user_email}", "status": "failed"}
        
        user_id = user.get("id")
        logger.info(f"✓ User: {user.get('displayName')}")
        
        # Gather all data
        logger.info("\n=== GATHERING DATA ===")
        roles = await graph.get_directory_roles(user_id)
        signin = await graph.get_signin_logs(user_id)
        rules = await graph.get_mailbox_rules(user_id)
        fwd = await graph.get_forwarding(user_id)
        devices = await graph.get_devices(user_id)
        device_details = await graph.get_device_details(user_id)
        mfa_methods = await graph.get_mfa_methods(user_id)
        user_licenses = await graph.get_user_licenses(user_id)
        victims = await graph.find_other_victims(incident.user_email)
        ca = await graph.check_conditional_access()
        pim_data = await graph.get_pim_assignments(user_id)
        delegated_access = await graph.get_delegated_mailbox_access(incident.user_email)
        oauth_apps = await graph.get_oauth_apps(user_id)
        
        graph_data = {
            "mailbox_rules": rules,
            "forwarding": fwd.get("forwarding"),
            "signin_logs": signin,
            "devices": devices,
            "device_details": device_details,
            "mfa_methods": mfa_methods,
            "roles": roles,
            "victims": victims,
            "ca_policies": ca,
            "pim_data": pim_data,
            "delegated_access": delegated_access,
            "oauth_apps": oauth_apps,
            "email": incident.user_email,
            "user_licenses": user_licenses,
            "suspicious_rules": [],  # filled after analysis below
        }
        
        logger.info(f"✓ Data gathered: {len(roles)} roles, {len(mfa_methods)} MFA methods, {len(signin)} sign-ins")
        
        # AI analysis with phishing protocol context
        logger.info("\n=== AI THREAT ANALYSIS ===")
        ai_analysis = await ai.analyze_threat(
            "Account compromise/phishing investigation",
            graph_data
        )
        
        # User activity
        user_activity = await user_analyzer.analyze_user_activity(graph, user_id, incident.user_email)
        affected_users = await user_analyzer.find_affected_users(graph, incident.user_email)
        
        phishing_victims = await graph.get_phishing_victims(incident.user_email)
        suspicious_rules = await graph.get_suspicious_email_rules(user_id)
        graph_data["suspicious_rules"] = suspicious_rules  # pass to executor
        
        # Full forensic analysis
        logger.info("\n=== FULL FORENSIC ANALYSIS ===")
        forensic = ForensicAnalyzer(graph)
        forensic_findings = await forensic.full_forensic_analysis(user_id, incident.user_email)
        
        privilege = analyzer.detect_privilege(roles)
        findings = analyzer.analyze(graph_data)
        signin_analysis = analyzer.analyze_signin_logs(signin)
        
        admin_data = {
            "audit_logs": [],
            "new_users": [],
            "new_licenses": [],
            "oauth_apps": []
        }
        
        if privilege.get("is_privileged"):
            logger.info("\n=== ADMIN USER - COLLECTING FORENSIC DATA ===")
            admin_data["audit_logs"] = await graph.get_audit_logs(incident.user_email, days_back=7)
            admin_data["new_users"] = await graph.get_new_users_created(days_back=7)
            admin_data["new_licenses"] = await graph.get_new_licenses()
            logger.info("✓ Admin forensics collected")
        
        response = {
            "status": "analysis_complete",
            "user": {
                "displayName": user.get("displayName"),
                "email": incident.user_email,
                "privileged": privilege.get("is_privileged"),
                "roles": privilege.get("all_roles") if privilege.get("all_roles") else roles if roles else [],
                "jobTitle": user.get("jobTitle", ""),
                "department": user.get("department", ""),
                "country": user.get("country", ""),
                "accountEnabled": user.get("accountEnabled", True),
                "userType": user.get("userType", "Member"),
                "createdDateTime": user.get("createdDateTime", ""),
            },
            "threat_score": ai_analysis.get("threat_score"),
            "threat_indicators": ai_analysis.get("indicators", []),
            "ai_summary": ai_analysis.get("analysis", ""),
            "findings": findings,
            "user_activity": user_activity,
            "affected_users": affected_users,
            "victims": victims,
            "mailbox_rules": len(rules),
            "devices": len(devices),
            "device_details": device_details,
            "mfa_methods": len(mfa_methods),
            "mfa_details": mfa_methods,
            "user_licenses": user_licenses,
            "signin_analysis": signin_analysis,
            "signin_logs_raw": signin[:20],
            "pim_data": pim_data,
            "delegated_access": delegated_access,
            "oauth_apps_raw": oauth_apps,
            "admin_data": admin_data,
            "phishing_victims": phishing_victims,
            "suspicious_rules": suspicious_rules,
            "forensic_analysis": forensic_findings,
            "requires_approval": privilege.get("is_privileged")
        }
        
        # Cache full data including graph_data for chat
        current_analysis[analysis_key] = {
            "user_id": user_id,
            "user_email": incident.user_email,
            "graph_data": graph_data,
            "privilege": privilege,
            **response
        }
        
        await graph.cleanup()
        await ai.cleanup()
        
        logger.info(f"\n✓ ANALYSIS COMPLETE")
        return response
    
    except Exception as e:
        import traceback
        logger.error(f"\nERROR: {e}")
        traceback.print_exc()
        return {"error": str(e), "status": "failed"}


@app.post("/api/ask-ai")
async def ask_ai(request: AIQuestion):
    """Ask anything about the compromised user - full context AI agent"""
    try:
        analysis_key = request.user_email.replace("@", "_").replace(".", "_")
        if analysis_key not in current_analysis:
            return {"answer": "No analysis found — run analysis for this user first.", "status": "error"}
        
        analysis = current_analysis[analysis_key]
        graph_data = analysis.get("graph_data", {})
        forensic_data = analysis.get("forensic_analysis", {})
        admin_data = analysis.get("admin_data", {})
        
        # Build comprehensive context for the AI agent
        signin_logs = graph_data.get("signin_logs", [])
        signin_detail = ""
        if signin_logs:
            signin_detail = f"Sign-in logs ({len(signin_logs)} total, showing last 15):\n"
            for s in signin_logs[:15]:
                loc = s.get("location", {})
                city = loc.get("city", "?")
                country = loc.get("countryOrRegion", "?")
                ip = s.get("ipAddress", "?")
                time = s.get("createdDateTime", "?")
                status_code = s.get("status", {}).get("errorCode", 0)
                status = "✓ Success" if status_code == 0 else f"✗ Failed ({status_code})"
                signin_detail += f"  {time}: {city}, {country} | IP: {ip} | {status}\n"
        
        device_detail = ""
        devices = graph_data.get("device_details", [])
        if devices:
            device_detail = f"Devices ({len(devices)}):\n"
            for d in devices:
                device_detail += f"  - {d.get('name','?')} | {d.get('type','?')} | {d.get('os','?')} | Added: {d.get('created','?')} | Last: {d.get('lastSignIn','?')}\n"
        
        audit_detail = ""
        if admin_data.get("audit_logs"):
            audit_detail = f"Audit log ({len(admin_data['audit_logs'])} entries):\n"
            for log in admin_data["audit_logs"][:10]:
                audit_detail += f"  - {log.get('time','?')}: {log.get('activity','?')} — {log.get('result','?')}\n"
        
        new_users_detail = ""
        if admin_data.get("new_users"):
            new_users_detail = f"New users created recently ({len(admin_data['new_users'])}):\n"
            for u in admin_data["new_users"]:
                new_users_detail += f"  - {u.get('name','?')} ({u.get('email','?')}) created {u.get('created','?')}\n"
        
        oauth_detail = ""
        raw_oauth = analysis.get("oauth_apps_raw", [])
        if raw_oauth:
            dangerous = [a for a in raw_oauth if a.get("dangerous")]
            highrisk  = [a for a in raw_oauth if a.get("highRisk") and not a.get("dangerous")]
            oauth_detail = f"OAuth app grants: {len(raw_oauth)} total, {len(dangerous)} dangerous, {len(highrisk)} high-risk\n"
            for app in dangerous:
                oauth_detail += f"  🚨 DANGEROUS: {app.get('appName','?')} — Scope: {app.get('scope','?')}\n"
            for app in highrisk[:3]:
                oauth_detail += f"  ⚠ High-risk: {app.get('appName','?')} — Scope: {app.get('scope','?')}\n"
            safe = [a for a in raw_oauth if not a.get("dangerous") and not a.get("highRisk")]
            for app in safe[:3]:
                oauth_detail += f"  - {app.get('appName','?')} — Scope: {app.get('scope','?')}\n"
        
        sharing_detail = ""
        if forensic_data.get("onedrive"):
            od = forensic_data["onedrive"]
            sharing_detail = f"OneDrive/SharePoint external shares: {len(od.get('external_collaborators', []))}\n"
            for share in od.get("external_collaborators", [])[:5]:
                sharing_detail += f"  - {share}\n"
        
        # Build conversation history for multi-turn
        messages = []
        if request.conversation_history:
            for msg in request.conversation_history[-6:]:  # Last 3 exchanges
                messages.append(msg)
        
        context = f"""USER QUESTION: {request.question}

FULL INCIDENT DATA:
Email: {analysis.get('user_email')}
Threat score: {analysis.get('threat_score')}/100
Privileged: {analysis.get('user', {}).get('privileged', False)}
Roles: {', '.join(analysis.get('user', {}).get('roles', [])) or 'None'}
MFA methods: {graph_data.get('mfa_methods', [])}
Mailbox rules: {graph_data.get('mailbox_rules', [])}
Email forwarding: {graph_data.get('forwarding') or 'None'}
Victims found: {len(analysis.get('victims', []))}
{signin_detail}
{device_detail}
{audit_detail}
{new_users_detail}
{oauth_detail}
{sharing_detail}
Forensic risk: {forensic_data.get('risk_summary', {}).get('overall_risk', 'UNKNOWN')}
Key forensic findings: {', '.join(forensic_data.get('risk_summary', {}).get('all_findings', [])) or 'None'}
"""
        
        ai = AIAnalyzer(os.getenv("GITHUB_TOKEN", ""))
        result = await ai.analyze_question(context, graph_data)
        await ai.cleanup()
        
        return {"answer": result, "status": "success"}
    
    except Exception as e:
        logger.error(f"AI error: {e}")
        import traceback
        traceback.print_exc()
        return {"answer": f"Error: {str(e)}", "status": "error"}


@app.post("/api/remediate")
async def remediate(approval: RemediationApproval):
    """Execute 8-step remediation"""
    try:
        if not current_analysis:
            return {"error": "No analysis found — run analysis first.", "status": "failed"}

        # Pick the analysis for the user the request names; fall back to the
        # only one in cache if no email was sent (keeps older clients working).
        if approval.user_email:
            analysis_key = approval.user_email.replace("@", "_").replace(".", "_")
            if analysis_key not in current_analysis:
                return {"error": f"No analysis found for {approval.user_email} — run analysis first.", "status": "failed"}
        else:
            analysis_key = list(current_analysis.keys())[0]
        analysis = current_analysis[analysis_key]

        if not approval.approve:
            return {"status": "cancelled"}
        
        logger.info(f"\n{'='*70}\nEXECUTING REMEDIATION: {analysis['user_email']}\n{'='*70}\n")
        
        graph = GraphClient(config.TENANT_ID, config.CLIENT_ID, config.CLIENT_SECRET)
        analyzer = Analyzer()
        
        executor = Executor(graph, analyzer)
        result = await executor.execute(
            analysis['user_email'],
            analysis['user_id'],
            analysis['graph_data'],
            is_admin=analysis.get('requires_approval', False)
        )
        
        await graph.cleanup()
        # Keep analysis cache — user may want to ask questions after remediation
        # current_analysis[analysis_key] remains available

        logger.info(f"\n✓ REMEDIATION COMPLETE")
        return {
            "status": result.get("status"),
            "password": result.get("password"),
            "execution_log": result.get("log", [])
        }
    
    except Exception as e:
        import traceback
        logger.error(f"\nERROR: {e}")
        traceback.print_exc()
        return {"error": str(e), "status": "failed"}
